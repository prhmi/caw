#pragma once
#include <string>
#include <vector>
#include <map>
#include <array>
#include <atomic>
#include <memory>
#include <mutex>
#include <cstdint>
#include <functional>
// One VST3 track as the Csound engine thread sees it.
struct VstJob {
    int id = 0;                    // Track::id: the Csound channels are cawvst_<id>_...
    int meterFirst = -1;           // stereo indices in the monitor snapshot, -1 disables metering
    int meterCount = 0;            // how many monitor slots the layout gave this track (the rack never writes past them)
    std::string name;              // track name = the audio bus name used by cawsa "name", aL, aR
    std::string path;              // .vst3 file
    std::string classId;           // the class inside the file (a bundle can hold several); empty = first
    std::map<uint32_t, double> parameterState; // stable plugin parameter IDs
    std::string stateBlob;         // SEPARATED ENGINES: the editor instance's full plugin state (Kontakt's loaded
                                   // .nki etc. - binary state, not a parameter). The rack applies it to the engine
                                   // instance at creation; a live change arrives via VstRack::pushState instead.
    bool instrument = true;        // true = VSTi (MIDI in), false = VSTe (audio in)
    float trackVolume = 1.f;       // the track volume fader (linear 0..2): applied where the track's output joins the master
    std::vector<int> pick;         // plugin parameter index of kP1..kP8
    std::vector<double> init;      // start value of kP1..kP8 (normalized)
    // The 8 VSTe input slots, mirroring Track::vstInputs. The rack copies every ENABLED slot's
    // lines into the plugin input packed from line 1, so switching an input on/off live never
    // leaves silent gaps in front of a later input. lineStart / lineCount say how many lines the
    // slot occupies; the sources are resolved BY NAME every block, so a re-wire works live.
    //   mode 0 = track, 1 = clips, 2 = master (spout copy).
    //   engine 0 = Csound clips: csChans holds one channel per line (cawtap_<clip>_<ch>, the
    //              per-clip output taps the CSD publishes - read live, resolved by name);
    //             1 = the Pure Data mix (rendered by the PD bridge outside Csound);
    //             2 = the SuperCollider mix (rendered in CAW's audio callback);
    //             3 = a VSTi / VSTe source (srcId = its track id): the rack wires the source
    //                 plugin's own stereo output into the slot, exactly the channels the source
    //                 sends to the master - a VST track's audio never runs through Csound.
    //             PD / SC / VST sources cannot be split per clip: the whole source mix feeds the slot.
    struct Input {
        bool on = false; int mode = 0; std::string name; bool sidechain = false; int lineStart = 0; int lineCount = 0;
        int receive = 0;   // 0 = stereo fold (ch k -> line k mod 2), 1 = multichannel (ch k -> line k) - wide track sources only
        int engine = 0; int srcId = 0;
        std::vector<std::string> csChans;   // engine 0 only: the tap channel of every line
    };
    Input inputs[8];
    bool routedIn = false;         // true if any input is configured (the 8-line buffer is used instead of silence)
    // VSTe EFFECT CHAIN: stages 2..8 IN ORDER (the input of stage k is the output of stage k-1).
    // Stage 0 = this job's own plugin (path / classId above). Empty = the single-plugin VSTe.
    struct ChainStage {
        std::string path, classId;
        std::map<uint32_t, double> parameterState;
        std::string stateBlob;         // SEPARATED ENGINES: the editor instance's patch state for this stage
    };
    std::vector<ChainStage> chain;
    std::array<int, 8> slotStage{};    // which stage each P slot drives: 0 = the job's plugin, 1..7 = chain[k-1]
    bool outMapOn = false;             // the track's routing text is active: outMap replaces the Out stereo / Out source fold
    std::array<int, 8> outMap{};       // per OUTPUT line (0-based): the chain-end input channel it plays, -1 = silent
    int outMode = 0;               // 0 = master (replace source), 1 = mix (source + VSTe to master)
    int outWide = 0;               // 0 = stereo fold at the meters / master join, 1 = the plugin's own channels 1:1
    int channels = 2;              // TRACK CHANNELS (1..8): the width the plugin is processed at, the meters and the master join
    unsigned bypass = 0;           // bit k = effect k+1 is bypassed (its input passes straight through; it is not processed)
};
// Engine thread -> UI thread mirror of the parameter values the rack is actually using. The UI
// reflects them into the plugin editor GUI (so automation moves the knobs) without touching the
// audio path. Values are the normalized kP1..kP8 channel values per VstJob::id.
struct VstParamMirror {
    std::mutex mutex;
    std::map<int, std::array<double, 8>> values;
};
// One manual parameter override from the UI: the rack applies it on the SAME block (it bypasses
// the Csound channels completely), so a slider drag is always heard immediately - even while a
// clip overwrites the channel, while no clip runs at all, or while automation moves the lane.
struct VstParamOverride {
    int trackId = 0; int slot = 0; double value = 0;   // slot = 0..7 (kP1..kP8), value normalized 0..1
    int stage = 0;                                     // the chain stage the slot's plugin sits on (0 = the first effect)
};
// PortAudio callback -> engine thread ring with a source's channels (interleaved, up to 8). The
// callback produces at device rate, the engine consumes one Csound block per block; the ring
// absorbs the clock drift (oldest frames are dropped on overrun, underruns read as silence).
// Wide sources (a SuperCollider track slot, a wide sample voice) store ALL their channels: the
// consumer folds them to stereo (the virtual soundcard rule) or takes them 1:1 (multi receive).
struct CawScRing {
    static constexpr int CH = 8;                       // channels stored per frame
    static constexpr size_t CAP = 1u << 16;            // frames of audio
    std::array<float, CAP * CH> buf{};
    std::atomic<size_t> r{0}, w{0};                    // frame positions, wrapping
    void push(const float* interleaved, size_t frames) {   // callback thread: device-scale samples
        pushStride2(interleaved, frames, 2);
    }
    void pushStride2(const float* interleaved, size_t frames, int stride) {   // wide-slot source: every channel up to 8
        if (!interleaved || stride < 1) return;
        for (size_t i = 0; i < frames; ++i) {
            const size_t wpos = w.load(std::memory_order_relaxed);
            if ((wpos + 1) % CAP == r.load(std::memory_order_acquire))
                r.store((r.load(std::memory_order_relaxed) + 1) % CAP, std::memory_order_release);   // full: drop the oldest
            float* dst = &buf[(size_t)wpos * CH];
            for (int c = 0; c < CH; ++c)
                dst[c] = c < stride ? interleaved[i * (size_t)stride + c] : 0.f;
            w.store((wpos + 1) % CAP, std::memory_order_release);
        }
    }
    size_t popSome(float* out, size_t frames) {            // engine thread: consumes only available frames (frames*CH floats)
        size_t got = 0;
        for (; got < frames; ++got) {
            const size_t rpos = r.load(std::memory_order_relaxed);
            if (rpos == w.load(std::memory_order_acquire)) break;
            std::copy_n(&buf[(size_t)rpos * CH], CH, out + got * CH);
            r.store((rpos + 1) % CAP, std::memory_order_release);
        }
        return got;
    }
    void pop(float* out, size_t frames) {                  // engine thread: fills exactly frames*CH floats
        const size_t got = popSome(out, frames);
        for (size_t i = got; i < frames; ++i)
            for (int c = 0; c < CH; ++c) out[i * CH + c] = 0.f;
    }
    // Drops the buffered audio (a consumer that starts late would otherwise stay a whole ring
    // behind forever: the backlog never drains once both sides run at the same rate).
    void reset() { r.store(0, std::memory_order_release); w.store(0, std::memory_order_release); }
    size_t queued() const {   // frames waiting (not thread-safe to combine with pop, but fine for a heuristic)
        const size_t wv = w.load(std::memory_order_acquire), rv = r.load(std::memory_order_acquire);
        return (wv + CAP - rv) % CAP;
    }
    void skip(size_t frames) {   // consumer-side catch-up: jump ahead to the newest audio
        const size_t q = queued();
        if (frames > q) frames = q;
        r.store((r.load(std::memory_order_relaxed) + frames) % CAP, std::memory_order_release);
    }
};
// Handoff of engine-side realtime mixes to the VST rack (set once before the rack starts).
struct VstEngineAudio {
    const std::atomic<const float*>* pdMix = nullptr;  // the latest Pure Data render (interleaved, pdMixChannels)
    int pdMixChannels = 2;
    CawScRing* pdRing = nullptr;                       // the dedicated PD engine's live stereo mix ring (engine 1, preferred over pdMix)
    CawScRing* scRing = nullptr;                       // the whole SuperCollider device mix (fallback / mode-2 "master")
    std::function<CawScRing*(int)> scTrackRing;        // one SuperCollider ring per TRACK SLOT (engine 2): the SC callback pushes, the rack pops
    std::function<CawScRing*(int)> sampleRing;         // a sample track's stereo mix ring (engine 4): the callback pushes, the rack pops
};
// One note of the MIDI clips of the VSTi tracks, as the app hands them to CAW's own VST engine
// (the 4th engine, while Csound is off). It plays them on its block clock. While Csound hosts,
// the Csound score plays the same clips into the note ring instead - one transport, one clock.
struct VstPlayNote {
    double start = 0.0, dur = 0.0;   // seconds on the timeline
    int trackId = 0, pitch = 60, velocity = 100;
};
