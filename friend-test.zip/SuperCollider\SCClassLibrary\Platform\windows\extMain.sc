+ Main {
	platformClass { ^WindowsPlatform }
}
