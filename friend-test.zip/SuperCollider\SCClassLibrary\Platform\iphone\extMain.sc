+ Main {
	platformClass { ^IPhonePlatform }
}
