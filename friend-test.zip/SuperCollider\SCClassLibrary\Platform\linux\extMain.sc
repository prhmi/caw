+ Main {
	platformClass { ^LinuxPlatform }
}
